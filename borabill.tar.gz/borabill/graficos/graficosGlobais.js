 

 async function visualizarInformacoesGlobais(){
  const res = await fetch (URL);
  const dados = res.json()
  console.log(dados);

 }

 v